/*
	## Funções construtoras
*/
// Calcula a largura de um elemento.
function width (width) {return width.innerWidth || width.clientWidth || document.documentElement.clientWidth;}
// Calcula a altura de um elemento.
function height (height) {return height.innerHeight || height.clientHeight || document.documentElement.clientHeight;}
// Pega a distância do topo ao fazer scroll.
function scrollTopPosition (scrollTopPosition) {return scrollTopPosition.scrollTop || document.documentElement.scrollTop;}
// Pega a distância de um elemento para o topo.
function distTop (distTop) {return distTop.offsetTop;}
(function modal (){
	let modal, btModal, closeModal;

	modal = document.querySelector(".modal");
	btModal = document.querySelectorAll(".alt-base");
	closeModal = document.querySelector(".close-modal");

	if (modal) {
		for(let i = 0; i < btModal.length; i++){
			btModal[i].addEventListener("click", function (event){
				event.preventDefault();
				modal.style.top = "0";
			}, false)

			closeModal.addEventListener("click", function (){
				modal.removeAttribute("style");
			})
		}
	}
}());
/*
	Função para limitar o tamanho do container.
 	Para limitar basta adiciona no elemento data-limit="VALOR";
*/
(function limitContentCalc (){
	let allTag, dataLimit, widthBody, i;

	allTag 		= document.querySelectorAll("div, section, article, main, header, footer, aside, span, nav");
	widthBody 	= width(document.body || document.documentElement);
	i = 0;

	while( allTag[i] ) {
		dataLimit 	= allTag[i].getAttribute("data-limit");
		if (dataLimit)
			(widthBody <= dataLimit) ? (
				allTag[i].style.maxWidth = "100%",
				allTag[i].style.width = "100vw",
				allTag[i].style.padding = "0 1.5rem"
			) : (
				allTag[i].style.maxWidth = dataLimit + "px",
				allTag[i].style.padding = "0",
				allTag[i].style.width = "100vw",
				allTag[i].style.margin = "0 auto"
			)
			window.addEventListener('resize', () => {
				widthBody = width(document.body || document.documentElement);
				i = 0;
				while( allTag[i] ){
					dataLimit 	= allTag[i].getAttribute("data-limit");
					if (dataLimit)
						(widthBody <= dataLimit) ? (
							allTag[i].style.maxWidth = "100%",
							allTag[i].style.width = "100vw",
							allTag[i].style.padding = "0 1.5rem"
						) : (
							allTag[i].style.maxWidth = dataLimit + "px",
							allTag[i].style.padding = "0",
							allTag[i].style.width = "100vw",
							allTag[i].style.margin = "0 auto"
						)
					i++;
				}
			})//Fechamento do window
		i++;
	}
}());
// Menu responsivo
(function menuResponsivo (){
	let menuResponsivo, btActionMenu, closeMenu;

	menuResponsivo = document.querySelector(".main_nav-mobile");
	btActionMenu = document.querySelector(".bt-active-nav .fa-bars");
	closeMenu = document.querySelector(".close-menu");

	if(menuResponsivo || btActionMenu || closeMenu){
		btActionMenu.addEventListener('click', function (){
			menuResponsivo.classList.remove("hide-margin");
		});
		menuResponsivo.addEventListener('click', function (){
			menuResponsivo.classList.add("hide-margin");
		});
		closeMenu.addEventListener('click', function (){
			menuResponsivo.classList.add("hide-margin");
		});
	}
}());
// Busca CEP
function limpa_formulário_cep() {
					 //Limpa valores do formulário de cep.
					 document.getElementById('rua').value=("");
					 document.getElementById('bairro').value=("");
					 document.getElementById('cidade').value=("");
	 }

	 function meu_callback(conteudo) {
			 if (!("erro" in conteudo)) {
					 //Atualiza os campos com os valores.
					 document.getElementById('rua').value=(conteudo.logradouro);
					 document.getElementById('bairro').value=(conteudo.bairro);
					 document.getElementById('cidade').value=(conteudo.localidade) + ' / ' + (conteudo.uf);
			 } //end if.
			 else {
					 //CEP não Encontrado.
					 limpa_formulário_cep();
					 alert("CEP não encontrado.");
			 }
	 }

	 function pesquisacep(valor) {

			 //Nova variável "cep" somente com dígitos.
			 var cep = valor.replace(/\D/g, '');

			 //Verifica se campo cep possui valor informado.
			 if (cep != "") {

					 //Expressão regular para validar o CEP.
					 var validacep = /^[0-9]{8}$/;

					 //Valida o formato do CEP.
					 if(validacep.test(cep)) {

							 //Preenche os campos com "..." enquanto consulta webservice.
							 document.getElementById('rua').value="Localizando...";
							 document.getElementById('bairro').value="Localizando...";
							 document.getElementById('cidade').value="Localizando...";

							 //Cria um elemento javascript.
							 var script = document.createElement('script');

							 //Sincroniza com o callback.
							 script.src = 'https://viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';

							 //Insere script no documento e carrega o conteúdo.
							 document.body.appendChild(script);

					 } //end if.
					 else {
							 //cep é inválido.
							 limpa_formulário_cep();
							 alert("Formato de CEP inválido.");
					 }
			 } //end if.
			 else {
					 //cep sem valor, limpa formulário.
					 limpa_formulário_cep();
			 }
	 };
(function actionSearchCEP (){
	let cep = document.getElementById("cep");

	if (cep) {
		cep.addEventListener('blur', function(){
			pesquisacep(this.value);
		});
	}
}());
// Fast Orc
(function fastOrc (){
	let mainContent, fastOrc, btAction, dataBt, qtdList, spanQtd;

	mainContent = document.getElementById("main-content");
	fastOrc = document.querySelector(".fast-orc");
	btAction = document.querySelector(".action-fast");
	dataBt = btAction.getAttribute("data-status");
	qtdList = document.querySelectorAll(".list-fast-orc li");
	spanQtd = document.querySelector(".qtdItensFastOrc");

	spanQtd.innerText = qtdList.length;

	btAction.addEventListener("click", function (){
		if(dataBt === "close"){
			dataBt = "open";
			mainContent.style.marginLeft = "-" + width(fastOrc) + "px";
			mainContent.style.opacity = ".8";
			fastOrc.style.opacity = "1";
		}else if(dataBt === "open"){
			dataBt = "close";
			mainContent.removeAttribute("style");
			fastOrc.removeAttribute("style");
		}

	})
}());
/*
	Galeria
 	Para funcionar deve adicionar essas duas classes abaixo
 	owl-carousel owl-theme
 	Página de exemplos https://owlcarousel2.github.io/OwlCarousel2/docs/api-options.html
 	Exemplo de uso: Galeria pode ser usada para lista de clientes por ícones
*/
$('.gal_dvs-itens').owlCarousel({
	autoplay: true,
    loop:true,
    items: 5,
    lazyLoad:true,
    margin:10,
    dots: true,
    nav: false,
    // navText: ['<i class="fas fa-angle-left"></i>','<i class="fas fa-angle-right"></i>'],
    animateIn: "fadeIn",
    animateOut: "fadeOut",
    responsive: {
	    0 : {
	    	items: 2,
	    	margin:10
	    },
	    480 : {items: 2},
	    768 : {itens: 4}
	}
});
// Banner Home
$('.gal_banner-home').owlCarousel({
	autoplay: true,
    loop:true,
    items: 1,
    lazyLoad:true,
    dots: true,
    nav: false,
    // navText: ['<i class="fas fa-angle-left"></i>','<i class="fas fa-angle-right"></i>'],
    animateIn: "fadeIn",
    animateOut: "fadeOut",
});
// Function Isotop
(function isotop (){
	// Isotop
	// init Isotope
	var $grid = $('.cards').isotope({
		itemSelector: '.card-produto'
	});
	// filter functions
	var filterFns = {
		// show if number is greater than 50
		numberGreaterThan50: function() {
			var number = $(this).find('.number').text();
			return parseInt( number, 10 ) > 50;
		},
		// show if name ends with -ium
		ium: function() {
			var name = $(this).find('.name').text();
			return name.match( /ium$/ );
		}
	};
	// bind filter button click
	$('.filters-button-group').on( 'click', 'button', function() {
		var filterValue = $( this ).attr('data-filter');
		// use filterFn if matches value
		filterValue = filterFns[ filterValue ] || filterValue;
		$grid.isotope({ filter: filterValue });
	});
	// change is-checked class on buttons
	$('.button-group').each( function( i, buttonGroup ) {
		var $buttonGroup = $( buttonGroup );
		$buttonGroup.on( 'click', 'button', function() {
			$buttonGroup.find('.is-checked').removeClass('is-checked');
			$( this ).addClass('is-checked');
		});
	});
}());
// Notification
// request permission on page load
function notifyMe() {
  if (Notification.permission !== "granted")
    Notification.requestPermission();
  else {
    var notification = new Notification('NOVA OFERTA DISPONÍVEL!', {
      icon: 'assets/media/image/marcas/skf.png',
      body: "Rolamento SKF - 23080 CC/C3W33",
    });

    notification.onclick = function () {
      window.open("skf-23080-cc-c3w33.html");
    };
  }
};
window.setTimeout(() => {notifyMe();}, 6000);
